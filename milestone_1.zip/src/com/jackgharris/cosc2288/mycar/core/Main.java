//**** PACKAGE****\\
//This specifics what package this specific class this Main.java class
//is a part of.
package com.jackgharris.cosc2288.mycar.core;

public class Main {

    //**** JAVA PROGRAM ENTRY POINT ****\\
    //Our public static void main is the primary entry point for all
    //java applications, here we can see the only job of the main class
    //is to create an instance of the Application.
    public static void main (String[] args){

        new Application();

    }
}
